package com.edu;

public class examenAnyoPasadoEj2 {
	public static double frecuenciaMaximaRecomendada(int añoActual,String fechaNacimiento) {
		int edad = 0;
		double frecuenciaMaximaRecomendada = 0;
		if(fechaNacimiento.length() == 10) {
			edad = añoActual - Integer.valueOf(fechaNacimiento.substring(6,fechaNacimiento.length()));
			frecuenciaMaximaRecomendada = ((220 - edad) - ((220 - edad)*0.15));
		}else {
			frecuenciaMaximaRecomendada = -1;
		}
		return frecuenciaMaximaRecomendada;
	}
	public static void main(String[] args) {
		System.out.println(frecuenciaMaximaRecomendada(2022,"19/11/2003"));
	}

}
